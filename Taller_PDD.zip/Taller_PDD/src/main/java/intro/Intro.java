package intro;

public class Intro {
    public static void main(String[] args) {
        System.out.println("Patrones de Diseño.");
        System.out.println("a trabajar ........");
    }
}
