package structure.decorator;

public class Hamburguesa {
    
    public String getDescripcion(){
        return "Carne + Pan";
    }

}
