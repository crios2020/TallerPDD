package structure.composite;

public class PruebaCompuesto {
    public static void main(String[] args) {
        ProgramarProyecto pp=new ProgramarProyecto();
    }
}
