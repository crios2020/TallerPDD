package structure.composite;

public interface ItemProyecto {
   public int getTiempo();
   public void imprimir();

}
