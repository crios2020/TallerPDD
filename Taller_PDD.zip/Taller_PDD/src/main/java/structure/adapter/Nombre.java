package structure.adapter;

public class Nombre {
    //Esta clase podria estar en binario y no veriamos su codigo fuentes
    //pero igual podriamos crear su adapter
    private String nombreCompuesto;

    public String getNombreCompuesto() {
        return nombreCompuesto;
    }

    public void setNombreCompuesto(String nombreCompuesto) {
        this.nombreCompuesto = nombreCompuesto;
    }
    
}
