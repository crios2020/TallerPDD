package creation.factory;

public class SQLServerConnection extends Connection{
    
    @Override
    public String description(){
        return "Conexion SQLServer";
    }
    
}
