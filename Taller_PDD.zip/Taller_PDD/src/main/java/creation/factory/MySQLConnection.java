package creation.factory;

public class MySQLConnection extends Connection{
    
    @Override
    public String description(){
        return "Conexión MySQL!";
    }
    
}
