
package creation.factory;

public class GenericConnection extends Connection{
    
    @Override
    public String description(){
        return "Conexión Generica!";
    }
    
}
