package creation.factory;

public class PostgreSQLConnection extends Connection{

    @Override
    public String description(){
        return "Conexión PostgreSQL!";
    }
    
}
