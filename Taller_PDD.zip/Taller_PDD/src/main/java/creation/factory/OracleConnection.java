package creation.factory;

public class OracleConnection extends Connection{
    
    @Override
    public String description(){
        return "Conexión Oracle!";
    }
    
}
