package creation.factory;

public abstract class Connection {

   public String description(){
       return "Conexión Generica!";
   }
   
}
