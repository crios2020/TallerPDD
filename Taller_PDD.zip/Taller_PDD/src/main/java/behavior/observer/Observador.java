package behavior.observer;

public interface Observador {
    public void actualizar(String accion, String lugar);
}
