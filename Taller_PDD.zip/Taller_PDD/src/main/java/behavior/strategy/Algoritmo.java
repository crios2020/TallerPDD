package behavior.strategy;

public interface Algoritmo {
    public void moverse();
}
