package behavior.strategy;

public class AvionComercial extends Avion{
    public AvionComercial(){}
}
