package behavior.strategy;

public class EnTierra implements Algoritmo {

    @Override
    public void moverse() {
        System.out.println("Moviendose sobre ruedas");
    }

}
