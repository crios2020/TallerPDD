package behavior.strategy;

public class AvionRapido extends Avion{
    public void AvionRapido(){}
}
