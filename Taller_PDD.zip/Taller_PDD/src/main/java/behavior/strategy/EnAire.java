package behavior.strategy;

public class EnAire implements Algoritmo{

    @Override
    public void moverse() {
        System.out.println("Moviendose en los aires");
    }
    
}
