package behavior.strategy;

public class EnAireVeloz implements Algoritmo{

    @Override
    public void moverse() {
        System.out.println("Volando muy rapido!!!"); 
    }
    
}
