package behavior.state;

public interface Estado {
    public void ejecutarAccion();
}
