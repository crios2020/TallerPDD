package behavior.responsability;

public interface InterfaceAyuda {
    public void getAyuda(int tipoAyuda);
}
