package behavior.responsability.improved;

public interface InterfaceAyuda {
    public void getAyuda(String tipoAyuda);
}
