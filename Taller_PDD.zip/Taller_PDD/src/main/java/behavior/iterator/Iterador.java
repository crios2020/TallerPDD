package behavior.iterator;

public interface Iterador {
    public Object siguiente();
    public boolean tieneSiguiente();
}
